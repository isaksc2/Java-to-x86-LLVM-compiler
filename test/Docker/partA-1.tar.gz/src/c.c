#include <stdio.h>
int main() {
    printString("asdasd");
    return 0;




}