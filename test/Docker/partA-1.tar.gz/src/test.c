int f(int b, int a) {
  int c = 3;
  int d = 3;
  printInt(c);
  printInt(a);
  printInt(d);
  int h = 30;
  printInt(h);
  return 0 ;

}

int main() {
  if (true == true) { printInt(42); }
  printString("hi");
  printString("ayyyy");
  return 0 ;

}

