// count function parameters as initialized

int main() {

  printInt(fac(5));
  return 0 ;
}

int fac (int a) {
  int r;
  int n;
  int a1 = 1;
  int a2 = 1;
  int a3 = 1;
  int a4 = 1;
  int a5 = 1;
  int a6 = 1;
  int a7 = 1;
  int a8 = 1;
  int a9 = 1;
  int a10 = 1;
  int a11 = 1;
  int a12 = 1;
  int c = a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12;
  r = 1;
  n = a;
  r = r * n;
  n = n - 1;
  return r;
}
