int f(int b, int a, double q) {
  double c = 34.6*58.5+45.3;
  double x = 3;
  double xx = 5;
  double y = x/xx;
  int z = 3;
  int zz = 5;
  int zzz = z/zz;

}

