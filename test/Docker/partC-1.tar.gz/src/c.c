#include <stdio.h>
int main() {
    double a = 3.0f + 4.0f;
    return 0;




}