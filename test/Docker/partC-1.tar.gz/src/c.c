#include <stdio.h>
int main() {
    double a = 322.57 / 89.44;
    int p = f(a);
    return 0;
    float r = 2.67f / 67.3f;


}

int f(double b) {
    double c = b/2.0;
    return 3;
}