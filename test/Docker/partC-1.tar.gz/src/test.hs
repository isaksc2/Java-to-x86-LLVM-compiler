main :: IO ()
main = do
    if (True)
        then return ()
        else putStrLn "aasd"
    putStrLn "asdadasdasdasdasdasd"

