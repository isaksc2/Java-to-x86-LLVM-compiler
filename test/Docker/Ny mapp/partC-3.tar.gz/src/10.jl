// count function parameters as initialized

int main() {
  int a1 = 1;
  int a2 = 2;
  int a3 = 3;
  int a4 = 4;
  int a5 = 5;
  int a6 = 6;
  int a7 = 7;
  int a8 = 8;
  int a9 = 9;
  int a10 = 10;
  int a11 = 11;
  int a12 = 12;
  double d1 = 1.0;
  double d2 = 2.0;
  double d3 = 3.0;
  double d4 = 4.0;
  double d5 = 5.0;
  double d6 = 6.0;
  double d7 = 7.0;
  double d8 = 8.0;
  double d9 = 9.0;
  double d10 = 10.0;
  double d11 = 11.0;
  double d12 = 12.0;
  double d13 = 13.0;
  double d14 = 14.0;
  int c =    a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12;
  double n = d1+d2+d3+d4+d5+d6+d7+d8+d9+d10+d11+d12+d13+d14;
  return 0;
}
